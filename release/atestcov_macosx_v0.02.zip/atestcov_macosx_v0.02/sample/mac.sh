#!/bin/sh
../atestcov --testcase SampleTestCase.txt --param SampleParameter.txt

