atestcov 

* User Manual
https://github.com/hiro-iseri/atestcov/blob/master/manual/manual.md

* Github
https://github.com/hiro-iseri/atestcov

* Author
Hiroki Iseri(goyoki[atmark]gmail.com)